import { useState } from "react";
import { Search, Truck, Package, Clock, CheckCircle, Eye } from "lucide-react";

/**
 * Orders component with a responsive layout.
 * It displays a dashboard of order metrics and a table of recent orders.
 * The layout adapts for mobile, tablet, and desktop views.
 * @param {{ theme: string }} props
 */
export default function Orders({ theme }) {
  const isDark = theme === "dark";

  const [orders] = useState([
    { id: "ORD-2024-001", customer: "City Hospital", date: "2024-01-20", items: 8, amount: 5200, payment: "Pending", status: "Processing" },
    { id: "ORD-2024-002", customer: "Medicare Pharmacy", date: "2024-01-19", items: 12, amount: 5300, payment: "Paid", status: "Shipped" },
    { id: "ORD-2024-003", customer: "Regional Medical Center", date: "2024-01-18", items: 15, amount: 7500, payment: "Paid", status: "Delivered" },
    { id: "ORD-2024-004", customer: "HealthPlus Clinic", date: "2024-01-17", items: 5, amount: 2100, payment: "Refunded", status: "Cancelled" },
  ]);

  return (
    <div className={`p-4 md:p-6 ${isDark ? "bg-gray-900 text-gray-100" : "bg-gray-50 text-gray-900"}`}>
      {/* Page Header */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center mb-6">
        <div>
          <h1 className="text-2xl md:text-3xl font-bold">Orders</h1>
          <p className={`mt-1 text-sm ${isDark ? "text-gray-400" : "text-gray-500"}`}>
            Manage and track all customer orders
          </p>
        </div>
        <button className="mt-4 sm:mt-0 flex items-center px-4 py-2 bg-blue-600 text-white rounded-lg shadow-sm hover:bg-blue-700 transition-colors w-full sm:w-auto justify-center">
          <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 mr-2" viewBox="0 0 20 20" fill="currentColor">
            <path fillRule="evenodd" d="M10 5a1 1 0 011 1v3h3a1 1 0 110 2h-3v3a1 1 0 11-2 0v-3H6a1 1 0 110-2h3V6a1 1 0 011-1z" clipRule="evenodd" />
          </svg>
          Create Order
        </button>
      </div>

      {/* Dashboard Metrics */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
        {[
          { title: "Total Orders", value: "1,247", icon: <Package className="h-10 w-10 text-blue-600" /> },
          { title: "Processing", value: "23", icon: <Clock className="h-10 w-10 text-yellow-500" /> },
          { title: "Shipped", value: "45", icon: <Truck className="h-10 w-10 text-indigo-600" /> },
          { title: "Delivered", value: "1,179", icon: <CheckCircle className="h-10 w-10 text-green-600" /> },
        ].map((metric, idx) => (
          <div key={idx} className={`${isDark ? "bg-gray-800" : "bg-white"} rounded-lg shadow-sm p-5 flex items-center justify-between`}>
            <div>
              <p className={`text-sm font-medium ${isDark ? "text-gray-400" : "text-gray-500"}`}>{metric.title}</p>
              <h2 className="text-2xl font-bold mt-1">{metric.value}</h2>
            </div>
            {metric.icon}
          </div>
        ))}
      </div>

      {/* Filter and Search Bar */}
      <div className={`${isDark ? "bg-gray-800" : "bg-white"} rounded-lg shadow-sm p-4 mb-6`}>
        <div className="flex flex-col md:flex-row items-center gap-4">
          <div className="relative w-full md:w-1/3">
            <Search className={`absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 ${isDark ? "text-gray-400" : "text-gray-500"}`} />
            <input
              type="text"
              placeholder="Search orders..."
              className={`pl-10 pr-3 py-2 border rounded-lg w-full text-sm focus:outline-none focus:ring-2 focus:ring-blue-500
                ${isDark ? "bg-gray-700 border-gray-600 text-gray-100 placeholder-gray-400" : "bg-white border-gray-300 text-gray-900"}`}
            />
          </div>
          <select
            className={`border rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 w-full md:w-auto
              ${isDark ? "bg-gray-700 border-gray-600 text-gray-100" : "bg-white border-gray-300 text-gray-900"}`}
          >
            <option>All Status</option>
            <option>Processing</option>
            <option>Shipped</option>
            <option>Delivered</option>
            <option>Cancelled</option>
          </select>
          <button
            className={`flex items-center px-4 py-2 rounded-lg shadow-sm border hover:bg-gray-100 transition-colors w-full md:w-auto
              ${isDark ? "bg-gray-700 border-gray-600 text-gray-100 hover:bg-gray-600" : "bg-gray-50 border-gray-300 text-gray-700"}`}
          >
            Export Orders
          </button>
        </div>
      </div>

      {/* Order List Table */}
      <div className={`${isDark ? "bg-gray-800" : "bg-white"} rounded-lg shadow-sm p-4 md:p-6`}>
        <h2 className="text-base md:text-lg font-semibold mb-4">Recent Orders ({orders.length} orders)</h2>
        <div className="overflow-x-auto">
          <table className="min-w-full divide-y divide-gray-200 dark:divide-gray-700">
            <thead className={isDark ? "bg-gray-700" : "bg-gray-50"}>
              <tr>
                {["Order ID", "Customer", "Date", "Items", "Amount", "Payment", "Status", "Actions"].map((head) => (
                  <th key={head} scope="col" className={`px-3 md:px-6 py-3 text-left text-xs font-medium uppercase tracking-wider ${isDark ? "text-gray-300" : "text-gray-500"}`}>
                    {head}
                  </th>
                ))}
              </tr>
            </thead>
            <tbody className={`divide-y ${isDark ? "divide-gray-700 bg-gray-800" : "divide-gray-200 bg-white"}`}>
              {orders.map((order) => (
                <tr key={order.id} className={isDark ? "hover:bg-gray-700" : "hover:bg-gray-50"}>
                  <td className="px-3 md:px-6 py-4 whitespace-nowrap text-sm font-medium">{order.id}</td>
                  <td className="px-3 md:px-6 py-4 whitespace-nowrap text-sm">{order.customer}</td>
                  <td className="px-3 md:px-6 py-4 whitespace-nowrap text-sm">{order.date}</td>
                  <td className="px-3 md:px-6 py-4 whitespace-nowrap text-sm">{order.items} items</td>
                  <td className="px-3 md:px-6 py-4 whitespace-nowrap text-sm">${order.amount.toLocaleString()}</td>
                  <td className="px-3 md:px-6 py-4 whitespace-nowrap text-sm">
                    <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${
                      order.payment === "Pending" ? "bg-red-100 text-red-800" : "bg-blue-100 text-blue-800"
                    }`}>
                      {order.payment}
                    </span>
                  </td>
                  <td className="px-3 md:px-6 py-4 whitespace-nowrap">
                    <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${
                      order.status === "Processing" ? "bg-yellow-100 text-yellow-800" :
                      order.status === "Shipped" ? "bg-indigo-100 text-indigo-800" :
                      order.status === "Delivered" ? "bg-green-100 text-green-800" :
                      "bg-gray-100 text-gray-800"
                    }`}>
                      {order.status}
                    </span>
                  </td>
                  <td className="px-3 md:px-6 py-4 whitespace-nowrap text-sm font-medium">
                    <button className={`flex items-center gap-1 p-2 border rounded-lg transition-colors ${isDark ? "text-gray-300 border-gray-600 hover:bg-gray-700" : "text-gray-600 border-gray-300 hover:bg-gray-100"}`}>
                      <Eye className="w-5 h-5" /> View
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
