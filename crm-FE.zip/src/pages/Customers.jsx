import { useEffect, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { toast, ToastContainer } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import { Filter } from "lucide-react";
import { fetchCustomers, resetCustomerState, addCustomer, updateCustomer } from "../features/customers/customerSlice";
import { FiEye, FiEdit, FiTrash2 } from "react-icons/fi";
import { deleteCustomer, fetchSingleCustomer } from "../features/customers/customerSlice";

export default function Customers({ theme }) {
  const dispatch = useDispatch();
  const { customers, isLoading, isError, message } = useSelector((state) => state.customers);
  const [types, setTypes] = useState([]);
  const [showForm, setShowForm] = useState(false);
  const [newCustomer, setNewCustomer] = useState({
    name: "",
    initials: "",
    contact: "",
    phone: "",
    type: "",
    status: "Active",
  });
  const [isEditing, setIsEditing] = useState(false);
  const [editingCustomerId, setEditingCustomerId] = useState(null);
  const [showModal, setShowModal] = useState(false);
  const [selectedCustomer, setSelectedCustomer] = useState(null);
  const [filters, setFilters] = useState({
    search: "",
    status: "All Status",
    type: "All Types",
    date: "",
  });
  const [filteredCustomers, setFilteredCustomers] = useState([]);

  const isDark = theme === "dark";

  useEffect(() => {
    dispatch(fetchCustomers());
    return () => dispatch(resetCustomerState());
  }, [dispatch]);

  useEffect(() => {
    fetch("http://localhost:8000/api/types")
      .then((res) => res.json())
      .then((data) => setTypes(data))
      .catch((err) => console.error(err));
  }, []);

  useEffect(() => {
    // Apply filters whenever customers or filters change
    applyFilters();
  }, [customers, filters]);

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setNewCustomer((prev) => ({ ...prev, [name]: value }));
  };

  const handleEditClick = (customer) => {
    setNewCustomer({
      name: customer.name,
      initials: customer.initials,
      contact: customer.contact,
      phone: customer.phone,
      type: customer.type?.id || "",
      status: customer.status,
    });
    setEditingCustomerId(customer.id);
    setIsEditing(true);
    setShowForm(true);
  };

  const handleViewClick = async (id) => {
    try {
      const result = await dispatch(fetchSingleCustomer(id)).unwrap();
      setSelectedCustomer(result);
      setShowModal(true);
      toast.info(`Viewing: ${result.name}`);
      console.log("Single Customer:", result);
    } catch (err) {
      toast.error(err);
    }
  };

  const handleDeleteClick = async (id) => {
    if (!window.confirm("Are you sure you want to delete this customer?")) return;

    try {
      const result = await dispatch(deleteCustomer(id)).unwrap();
      toast.success(result.message);
    } catch (err) {
      toast.error(err);
    }
  };

  const handleSubmitCustomer = async (e) => {
    e.preventDefault();

    const customerData = {
      name: newCustomer.name,
      initials: newCustomer.initials,
      contact: newCustomer.contact,
      phone: newCustomer.phone,
      type_id: newCustomer.type,
      status: newCustomer.status,
    };

    try {
      if (isEditing) {
        const result = await dispatch(updateCustomer({ id: editingCustomerId, data: customerData })).unwrap();
        toast.success(result.message);
      } else {
        const result = await dispatch(addCustomer(customerData)).unwrap();
        toast.success(result.message);
      }
      resetForm();
      setShowForm(false);
      setIsEditing(false);
      setEditingCustomerId(null);
    } catch (err) {
      console.error(err);
      toast.error(err || "Failed to save customer.");
    }
  };

  const resetForm = () => {
    setNewCustomer({
      name: "",
      initials: "",
      contact: "",
      phone: "",
      type: "",
      status: "Active",
    });
  };

  const closeModal = () => {
    setShowModal(false);
    setSelectedCustomer(null);
  };

  // Handle filter input changes
  const handleFilterChange = (e) => {
    const { name, value } = e.target;
    setFilters((prev) => ({ ...prev, [name]: value }));
  };

  // Apply filters to the customer list
  const applyFilters = () => {
    let filtered = [...customers];

    // Search filter (case-insensitive search by name or contact)
    if (filters.search) {
      filtered = filtered.filter((customer) =>
        customer.name.toLowerCase().includes(filters.search.toLowerCase()) ||
        customer.contact.toLowerCase().includes(filters.search.toLowerCase())
      );
    }

    // Status filter
    if (filters.status !== "All Status") {
      filtered = filtered.filter((customer) => customer.status === filters.status);
    }

    // Type filter
    if (filters.type !== "All Types") {
      filtered = filtered.filter((customer) => customer.type?.type === filters.type);
    }

    // Date filter (simple match for created_at)
    if (filters.date) {
      filtered = filtered.filter((customer) => {
        const customerDate = new Date(customer.created_at).toLocaleDateString("en-GB"); // dd/mm/yyyy
        return customerDate === filters.date;
      });
    }

    setFilteredCustomers(filtered);
  };

  // Reset filters
  const resetFilters = () => {
    setFilters({
      search: "",
      status: "All Status",
      type: "All Types",
      date: "",
    });
  };

  return (
    <div className={`p-4 md:p-6 ${isDark ? "bg-gray-900 text-gray-100" : "bg-gray-50 text-gray-900"}`}>
      <ToastContainer position="top-right" autoClose={3000} />

      {/* Header */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center mb-6">
        <div>
          <h1 className={`text-2xl md:text-3xl font-bold ${isDark ? "text-white" : "text-gray-900"}`}>Customers</h1>
          <p className={`mt-1 text-xs md:text-sm ${isDark ? "text-gray-400" : "text-gray-500"}`}>
            Manage your customer relationships and view their activity
          </p>
        </div>
        <button
          onClick={() => { setShowForm(true); setIsEditing(false); resetForm(); }}
          className="mt-4 sm:mt-0 flex items-center px-4 py-2 bg-blue-600 text-white rounded-lg shadow-sm hover:bg-blue-700 transition-colors w-full sm:w-auto justify-center"
        >
          <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 mr-2" viewBox="0 0 20 20" fill="currentColor">
            <path fillRule="evenodd" d="M10 5a1 1 0 011 1v3h3a1 1 0 110 2h-3v3a1 1 0 11-2 0v-3H6a1 1 0 110-2h3V6a1 1 0 011-1z" clipRule="evenodd" />
          </svg>
          Add Customer
        </button>
      </div>

      {/* Customer Form Modal */}
      {showForm && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50">
          <div className={`rounded-lg p-6 w-full max-w-md ${isDark ? "bg-gray-800 text-gray-100" : "bg-white"}`}>
            <h2 className="text-lg font-semibold mb-4">{isEditing ? "Edit Customer" : "Add New Customer"}</h2>
            <form onSubmit={handleSubmitCustomer} className="flex flex-col gap-3">
              <input type="text" name="name" placeholder="Customer Name" value={newCustomer.name} onChange={handleInputChange} className="px-3 py-2 border rounded-lg w-full" required />
              <input type="text" name="initials" placeholder="Initials" value={newCustomer.initials} onChange={handleInputChange} className="px-3 py-2 border rounded-lg w-full" required />
              <input type="text" name="contact" placeholder="Email" value={newCustomer.contact} onChange={handleInputChange} className="px-3 py-2 border rounded-lg w-full" required />
              <input type="text" name="phone" placeholder="Phone" value={newCustomer.phone} onChange={handleInputChange} className="px-3 py-2 border rounded-lg w-full" required />
              <select name="type" value={newCustomer.type} onChange={handleInputChange} className="px-3 py-2 border rounded-lg w-full" required>
                <option value="">Select Type</option>
                {types.map((type) => (
                  <option key={type.id} value={type.id}>{type.type}</option>
                ))}
              </select>
              <select name="status" value={newCustomer.status} onChange={handleInputChange} className="px-3 py-2 border rounded-lg w-full">
                <option value="Active">Active</option>
                <option value="Pending">Pending</option>
                <option value="Inactive">Inactive</option>
              </select>
              <div className="flex justify-end gap-2 mt-2">
                <button type="button" onClick={() => { setShowForm(false); resetForm(); }} className="px-4 py-2 border rounded-lg">Cancel</button>
                <button type="submit" className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700">{isEditing ? "Update" : "Add"}</button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Customer View Modal */}
      {showModal && selectedCustomer && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 backdrop-blur-sm">
          <div
            className={`rounded-2xl p-6 w-full max-w-md shadow-2xl transform transition-all duration-300 scale-95 hover:scale-100 ${
              isDark ? "bg-gray-900 text-gray-100" : "bg-white text-gray-900"
            }`}
          >
            {/* Header */}
            <div className="flex items-center justify-between border-b pb-3 mb-4">
              <h2 className="text-xl font-bold flex items-center gap-2">
                👤 Customer Details
              </h2>
              <button
                onClick={closeModal}
                className="text-gray-500 hover:text-red-500 transition"
              >
                ✖
              </button>
            </div>
      
            {/* Customer Info */}
            <div className="space-y-3">
              <p><strong>Name:</strong> {selectedCustomer.name}</p>
              <p><strong>Initials:</strong> {selectedCustomer.initials}</p>
              <p><strong>Email:</strong> {selectedCustomer.contact}</p>
              <p><strong>Phone:</strong> {selectedCustomer.phone}</p>
              <p>
                <strong>Type:</strong>{" "}
                <span className="px-2 py-1 text-sm rounded-md bg-blue-100 text-blue-700">
                  {selectedCustomer.type?.type || "N/A"}
                </span>
              </p>
              <p>
                <strong>Status:</strong>{" "}
                <span
                  className={`px-2 py-1 text-sm rounded-md ${
                    selectedCustomer.status === "Active"
                      ? "bg-green-100 text-green-700"
                      : "bg-red-100 text-red-700"
                  }`}
                >
                  {selectedCustomer.status}
                </span>
              </p>
              <p><strong>Total Orders:</strong> {selectedCustomer.total_orders}</p>
              <p><strong>Total Amount:</strong> ₹{(selectedCustomer.total_amount || 0).toLocaleString()}</p>
              <p><strong>Since:</strong> {new Date(selectedCustomer.created_at).toLocaleDateString()}</p>
            </div>
      
            {/* Footer */}
            <div className="flex justify-end mt-6">
              <button
                onClick={closeModal}
                className="px-5 py-2 bg-gradient-to-r from-blue-500 to-indigo-600 text-white rounded-lg shadow-md hover:from-blue-600 hover:to-indigo-700 transition"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Search & Filter Section */}
      <div className={`${isDark ? "bg-gray-800" : "bg-white"} rounded-lg shadow-sm p-4 mb-6`}>
        <div className="flex flex-col md:flex-row items-center gap-4">
          {/* Search Input */}
          <div className="relative w-full md:w-1/3">
            <div className={`absolute left-3 top-1/2 -translate-y-1/2 ${isDark ? "text-gray-300" : "text-gray-400"}`}>
              <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" viewBox="0 0 16 16">
                <path d="M11.742 10.344a6.5 6.5 0 1 0-1.397 1.398h-.001c.03.04.062.078.098.115l3.85 3.85a1 1 0 0 0 1.415-1.414l-3.85-3.85a1.007 1.007 0 0 0-.115-.1zM12 6.5a5.5 5.5 0 1 1-11 0 5.5 5.5 0 0 1 11 0z"/>
              </svg>
            </div>
            <input
              type="text"
              name="search"
              placeholder="Search customers..."
              value={filters.search}
              onChange={handleFilterChange}
              className={`pl-10 pr-3 py-2 border rounded-lg w-full text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 ${isDark ? "bg-gray-700 border-gray-600 text-white placeholder-gray-400" : "bg-white border-gray-300 text-black"}`}
            />
          </div>

          {/* Filter Selects */}
          <select
            name="status"
            value={filters.status}
            onChange={handleFilterChange}
            className={`flex-1 border rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 ${isDark ? "bg-gray-700 border-gray-600 text-white" : "bg-white border-gray-300 text-black"}`}
          >
            <option value="All Status">All Status</option>
            <option value="Active">Active</option>
            <option value="Pending">Pending</option>
            <option value="Inactive">Inactive</option>
          </select>
          <select
            name="type"
            value={filters.type}
            onChange={handleFilterChange}
            className={`flex-1 border rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 ${isDark ? "bg-gray-700 border-gray-600 text-white" : "bg-white border-gray-300 text-black"}`}
          >
            <option value="All Types">All Types</option>
            <option value="Hospital">Hospital</option>
            <option value="Pharmacy">Pharmacy</option>
            <option value="Clinic">Clinic</option>
            <option value="Retail">Retail</option>
            <option value="Wholesale">Wholesale</option>
          </select>

          {/* Filter Buttons */}
          <div className="flex gap-2 w-full md:w-auto">
            <button
              onClick={applyFilters}
              className={`flex-1 flex items-center justify-center px-4 py-2 rounded-lg shadow-sm border transition-colors ${isDark ? "bg-gray-700 text-gray-200 border-gray-600 hover:bg-gray-600" : "bg-gray-50 text-gray-700 border-gray-300 hover:bg-gray-100"}`}
            >
              <Filter size={18} className="mr-2" />
              Filter
            </button>
            <button
              onClick={resetFilters}
              className={`px-4 py-2 rounded-lg shadow-sm border transition-colors ${isDark ? "bg-gray-700 text-gray-200 border-gray-600 hover:bg-gray-600" : "bg-gray-50 text-gray-700 border-gray-300 hover:bg-gray-100"}`}
            >
              ✕
            </button>
          </div>
        </div>
      </div>

      {/* Customer Table */}
      <div className={`${isDark ? "bg-gray-800" : "bg-white"} rounded-lg shadow-sm p-4 md:p-6 mt-4`}>
        <h2 className={`text-base md:text-lg font-semibold mb-4 ${isDark ? "text-white" : "text-gray-900"}`}>
          Customer List ({isLoading ? "Loading..." : `${filteredCustomers.length} customers`})
        </h2>

        {isError && <p className={`text-sm mb-4 ${isDark ? "text-red-400" : "text-red-600"}`}>{message}</p>}

        <div className="overflow-x-auto">
          <table className="min-w-full divide-y divide-gray-200 dark:divide-gray-700">
            <thead className={isDark ? "bg-gray-700" : "bg-gray-50"}>
              <tr>
                {["Customer", "Type", "Contact", "Total Orders", "Total Amount", "Status", "Actions"].map((head) => (
                  <th key={head} className={`px-3 md:px-6 py-3 text-left text-xs font-medium uppercase tracking-wider ${isDark ? "text-gray-300" : "text-gray-500"}`}>{head}</th>
                ))}
              </tr>
            </thead>
            <tbody className={isDark ? "bg-gray-800 divide-y divide-gray-700" : "bg-white divide-y divide-gray-200"}>
              {filteredCustomers.map((customer) => (
                <tr key={customer.id}>
                  <td className="px-3 md:px-6 py-4 whitespace-nowrap">
                    <div className="flex items-center">
                      <div className={`w-10 h-10 flex items-center justify-center text-white font-bold rounded-full mr-4 text-xs flex-shrink-0 ${customer.name.startsWith("Apollo") ? "bg-blue-600" : customer.name.startsWith("Medicare") ? "bg-green-600" : "bg-yellow-500"}`}>
                        {customer.initials}
                      </div>
                      <div>
                        <div className={`text-sm font-medium ${isDark ? "text-white" : "text-gray-900"}`}>{customer.name}</div>
                        <div className={`text-xs ${isDark ? "text-gray-400" : "text-gray-500"}`}>Since {new Date(customer.created_at).toLocaleDateString()}</div>
                      </div>
                    </div>
                  </td>
                  <td className="px-3 md:px-6 py-4 whitespace-nowrap">
                    <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${
                      customer.type?.type === "Retail" ? "bg-blue-100 text-blue-800" :
                      customer.type?.type === "Wholesale" ? "bg-green-100 text-green-800" : "bg-yellow-100 text-yellow-800"
                    }`}>
                      {customer.type?.type || "N/A"}
                    </span>
                  </td>
                  <td className="px-3 md:px-6 py-4 whitespace-nowrap">
                    <div className="text-xs text-blue-600">{customer.contact}</div>
                    <div className={`text-xs ${isDark ? "text-gray-400" : "text-gray-500"}`}>{customer.phone}</div>
                  </td>
                  <td className={`px-3 md:px-6 py-4 whitespace-nowrap text-sm ${isDark ? "text-gray-300" : "text-gray-500"}`}>{customer.total_orders}</td>
                  <td className={`px-3 md:px-6 py-4 whitespace-nowrap text-sm ${isDark ? "text-gray-300" : "text-gray-500"}`}>₹{(customer.total_amount || 0).toLocaleString()}</td>
                  <td className="px-3 md:px-6 py-4 whitespace-nowrap">
                    <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${
                      customer.status === "Active" ? "bg-green-100 text-green-800" :
                      customer.status === "Pending" ? "bg-yellow-100 text-yellow-800" :
                      "bg-red-100 text-red-800"
                    }`}>
                      {customer.status}
                    </span>
                  </td>
                  <td className="px-3 md:px-6 py-4 whitespace-nowrap text-sm font-medium">
                    <div className="flex gap-2">
                      <button 
                        onClick={() => handleViewClick(customer.id)} 
                        className={`p-2 border rounded-lg ${isDark ? "text-gray-300 border-gray-600 hover:bg-gray-700" : "text-gray-600 border-gray-300 hover:bg-gray-100"}`}>
                        <FiEye size={20} />
                      </button>
                      <button onClick={() => handleEditClick(customer)} className={`p-2 border rounded-lg ${isDark ? "text-gray-300 border-gray-600 hover:bg-gray-700" : "text-gray-600 border-gray-300 hover:bg-gray-100"}`}><FiEdit size={20} /></button>
                      <button 
                        onClick={() => handleDeleteClick(customer.id)} 
                        className={`p-2 border rounded-lg ${isDark ? "text-red-300 border-red-600 hover:bg-red-700" : "text-red-600 border-red-300 hover:bg-red-100"}`}>
                        <FiTrash2 size={20} />
                      </button>                   
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}