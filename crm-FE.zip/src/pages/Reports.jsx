import { TrendingUp, BarChart2, Users, FileText, Calendar, Download, Users as UsersIcon } from "lucide-react";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell } from 'recharts';

/**
 * A responsive dashboard component for reports and analytics.
 * @param {{ theme: string }} props
 */
export default function ReportsAnalytics({ theme }) {
  const isDark = theme === "dark";

  // Mock data for metrics
  const metrics = [
    {
      title: "Total Revenue",
      value: "$328,000",
      change: "+12.5% vs last month",
      changeColor: "text-green-600",
      icon: <TrendingUp className="h-10 w-10 text-green-600" />,
    },
    {
      title: "Orders Processed",
      value: "890",
      change: "+8.2% vs last month",
      changeColor: "text-blue-600",
      icon: <BarChart2 className="h-10 w-10 text-blue-600" />,
    },
    {
      title: "Active Customers",
      value: "847",
      change: "+5.3% vs last month",
      changeColor: "text-purple-600",
      icon: <Users className="h-10 w-10 text-purple-600" />,
    },
    {
      title: "Profit Margin",
      value: "18.5%",
      change: "+2.1% vs last month",
      changeColor: "text-orange-600",
      icon: <FileText className="h-10 w-10 text-orange-600" />,
    },
  ];

  // Chart data
  const salesData = [
    { name: "Jan", sales: 45000 },
    { name: "Feb", sales: 52000 },
    { name: "Mar", sales: 48000 },
    { name: "Apr", sales: 61000 },
    { name: "May", sales: 56000 },
    { name: "Jun", sales: 68000 },
  ];

  const salesByCategoryData = [
    { name: "Antibiotics", value: 35 },
    { name: "Analgesics", value: 25 },
    { name: "Diabetes", value: 20 },
    { name: "Gastroenterology", value: 15 },
    { name: "Others", value: 5 },
  ];
  const COLORS = ['#1D4ED8', '#059669', '#F59E0B', '#8B5CF6', '#6B7280'];

  // Report Templates
  const reportTemplates = [
    {
      icon: <TrendingUp className="h-6 w-6 text-blue-700" />,
      title: "Sales Summary Report",
      description: "Monthly sales performance and trends",
      lastUpdated: "2024-01-20",
    },
    {
      icon: <UsersIcon className="h-6 w-6 text-blue-700" />,
      title: "Customer Analysis Report",
      description: "Customer behavior and purchase patterns",
      lastUpdated: "2024-01-18",
    },
    {
      icon: <BarChart2 className="h-6 w-6 text-blue-700" />,
      title: "Inventory Status Report",
      description: "Stock levels and inventory valuation",
      lastUpdated: "2024-01-15",
    },
    {
      icon: <FileText className="h-6 w-6 text-blue-700" />,
      title: "Financial Statement",
      description: "Revenue, expenses, and profit analysis",
      lastUpdated: "2024-01-17",
    },
  ];

  return (
    <div className={`p-4 md:p-6 ${isDark ? "bg-gray-900 text-white" : "bg-gray-50 text-gray-900"}`}>
      {/* Header */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center mb-6">
        <div>
          <h1 className="text-2xl md:text-3xl font-bold">Reports & Analytics</h1>
          <p className={`mt-1 text-sm ${isDark ? "text-gray-400" : "text-gray-500"}`}>
            Generate insights and track business performance
          </p>
        </div>
        <div className="flex flex-col sm:flex-row space-y-2 sm:space-y-0 sm:space-x-2 mt-4 sm:mt-0 w-full sm:w-auto items-center">
          <div className="relative w-full sm:w-auto">
            <Calendar className={`absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 ${isDark ? "text-gray-400" : "text-gray-500"}`} />
            <input
              type="text"
              placeholder="Date Range"
              className={`pl-10 pr-3 py-2 border rounded-lg w-full text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 
                ${isDark ? "bg-gray-800 border-gray-700 text-white" : "bg-white border-gray-300"}`}
            />
          </div>
          <select
            className={`border rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 w-full sm:w-auto
              ${isDark ? "bg-gray-800 border-gray-700 text-white" : "bg-white border-gray-300"}`}
          >
            <option>Monthly</option>
            <option>Weekly</option>
            <option>Quarterly</option>
          </select>
          <button className="flex items-center justify-center px-4 py-2 bg-blue-600 text-white rounded-lg shadow-sm hover:bg-blue-700 transition-colors w-full sm:w-auto">
            <Download className="h-4 w-4 mr-2" />
            Export All
          </button>
        </div>
      </div>

      {/* Metrics */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
        {metrics.map((metric, index) => (
          <div key={index} className={`${isDark ? "bg-gray-800" : "bg-white"} rounded-lg shadow-sm p-5 flex items-center justify-between`}>
            <div>
              <p className={`text-sm font-medium ${isDark ? "text-gray-400" : "text-gray-500"}`}>{metric.title}</p>
              <h2 className="text-2xl font-bold mt-1">{metric.value}</h2>
              <p className={`mt-1 text-xs font-medium ${metric.changeColor}`}>{metric.change}</p>
            </div>
            {metric.icon}
          </div>
        ))}
      </div>

      {/* Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6">
        <div className={`${isDark ? "bg-gray-800" : "bg-white"} rounded-lg shadow-sm p-4 md:p-6`}>
          <h3 className="text-base md:text-lg font-semibold mb-4">Sales Trend (Last 6 months)</h3>
          <ResponsiveContainer width="100%" height={300}>
            <BarChart data={salesData}>
              <CartesianGrid strokeDasharray="3 3" stroke={isDark ? "#4B5563" : "#E5E7EB"} />
              <XAxis dataKey="name" stroke={isDark ? "#D1D5DB" : "#374151"} />
              <YAxis stroke={isDark ? "#D1D5DB" : "#374151"} />
              <Tooltip contentStyle={{ backgroundColor: isDark ? "#1F2937" : "#fff", color: isDark ? "#fff" : "#000", border: `1px solid ${isDark ? '#374151' : '#E5E7EB'}` }} />
              <Bar dataKey="sales" fill="#1D4ED8" />
            </BarChart>
          </ResponsiveContainer>
        </div>
        <div className={`${isDark ? "bg-gray-800" : "bg-white"} rounded-lg shadow-sm p-4 md:p-6`}>
          <h3 className="text-base md:text-lg font-semibold mb-4">Sales by Category</h3>
          <ResponsiveContainer width="100%" height={300}>
            <PieChart>
              <Pie
                data={salesByCategoryData}
                dataKey="value"
                nameKey="name"
                cx="50%"
                cy="50%"
                outerRadius={100}
                innerRadius={70}
                label
              >
                {salesByCategoryData.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                ))}
              </Pie>
              <Tooltip contentStyle={{ backgroundColor: isDark ? "#1F2937" : "#fff", color: isDark ? "#fff" : "#000", border: `1px solid ${isDark ? '#374151' : '#E5E7EB'}` }} />
            </PieChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Report Templates */}
      <div className="mb-6">
        <h2 className="text-xl font-bold mb-4">Report Templates</h2>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {reportTemplates.map((template, index) => (
            <div key={index} className={`${isDark ? "bg-gray-800" : "bg-white"} rounded-lg shadow-sm p-6`}>
              <div className="flex items-start space-x-4">
                <div className="p-3 bg-blue-100 rounded-full flex-shrink-0">
                  {template.icon}
                </div>
                <div className="flex-grow">
                  <h4 className="text-lg font-semibold">{template.title}</h4>
                  <p className={`text-sm ${isDark ? "text-gray-400" : "text-gray-500"}`}>{template.description}</p>
                </div>
              </div>
              <p className={`mt-4 text-xs ${isDark ? "text-gray-500" : "text-gray-400"}`}>Last: {template.lastUpdated}</p>
              <div className="flex flex-col sm:flex-row space-y-2 sm:space-y-0 sm:space-x-2 mt-4">
                <button className={`flex items-center justify-center px-3 py-1 rounded-md text-sm transition-colors w-full sm:w-auto ${isDark ? "bg-gray-700 text-white hover:bg-gray-600" : "bg-gray-50 text-gray-700 hover:bg-gray-100"}`}>
                  <Download className="h-3 w-3 mr-1" /> PDF
                </button>
                <button className={`flex items-center justify-center px-3 py-1 rounded-md text-sm transition-colors w-full sm:w-auto ${isDark ? "bg-gray-700 text-white hover:bg-gray-600" : "bg-gray-50 text-gray-700 hover:bg-gray-100"}`}>
                  <Download className="h-3 w-3 mr-1" /> Excel
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}