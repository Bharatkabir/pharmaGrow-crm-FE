import { useState } from "react";
import {
  User,
  Bell,
  Edit,
  Trash,
  Mail,
  Phone,
  Shield,
  Wifi,
} from "lucide-react";

/**
 * A responsive settings dashboard component.
 * @param {{ theme: string }} props
 */
export default function Settings({ theme }) {
  const isDark = theme === "dark";

  const [users, setUsers] = useState([
    { id: 1, name: "John Doe", role: "Super Admin", initials: "JD", color: "bg-blue-500" },
    { id: 2, name: "Sarah Manager", role: "Admin", initials: "SM", color: "bg-green-600" },
    { id: 3, name: "Rahul Sales", role: "Sales Representative", initials: "RS", color: "bg-cyan-500" },
  ]);

  const [notifications, setNotifications] = useState({
    email: true,
    whatsapp: true,
    sms: false,
    stock: true,
  });

  const toggleNotification = (type) => {
    setNotifications((prev) => ({ ...prev, [type]: !prev[type] }));
  };

  return (
    <div
      className={`p-4 md:p-6 min-h-screen transition-colors ${
        isDark ? "bg-gray-900 text-gray-200" : "bg-gray-50 text-gray-900"
      }`}
    >
      <h1 className="text-2xl md:text-3xl font-bold mb-1">Settings</h1>
      <p className="text-sm md:text-base mb-6">Manage your account settings and preferences</p>

      {/* Main content grid. Uses 1 column on small screens, 2 columns on medium screens and up */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* User Management */}
        <div
          className={`rounded-lg shadow-sm border overflow-hidden ${
            isDark ? "bg-gray-800 border-gray-700" : "bg-white border-gray-200"
          }`}
        >
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between p-4 border-b">
            <h2 className="font-semibold text-lg mb-2 sm:mb-0">User Management</h2>
            <button
              className="px-3 py-1 rounded-md bg-blue-600 text-white text-sm hover:bg-blue-700 w-full sm:w-auto"
            >
              + Add User
            </button>
          </div>
          <div>
            {users.map((user) => (
              <div
                key={user.id}
                className={`flex items-center justify-between p-4 border-b last:border-b-0 ${
                  isDark ? "border-gray-700" : "border-gray-200"
                }`}
              >
                <div className="flex items-center gap-3">
                  <div
                    className={`w-9 h-9 rounded-full flex items-center justify-center text-white font-medium flex-shrink-0 ${user.color}`}
                  >
                    {user.initials}
                  </div>
                  <div className="min-w-0">
                    <p className="font-medium truncate">{user.name}</p>
                    <p className="text-xs text-gray-500 truncate">{user.role}</p>
                  </div>
                </div>
                <div className="flex items-center gap-2 flex-shrink-0">
                  <button className="p-2 rounded-full hover:bg-gray-100 dark:hover:bg-gray-700">
                    <Edit size={16} className="text-blue-600" />
                  </button>
                  <button className="p-2 rounded-full hover:bg-gray-100 dark:hover:bg-gray-700">
                    <Trash size={16} className="text-red-500" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Notifications & Reminders */}
        <div
          className={`rounded-lg shadow-sm border ${
            isDark ? "bg-gray-800 border-gray-700" : "bg-white border-gray-200"
          }`}
        >
          <div className="p-4 border-b">
            <h2 className="font-semibold text-lg">Notifications & Reminders</h2>
          </div>
          <div className="divide-y">
            {[
              { key: "email", label: "Email Notifications", desc: "Receive notifications via email" },
              { key: "whatsapp", label: "WhatsApp Reminders", desc: "Send payment reminders via WhatsApp" },
              { key: "sms", label: "SMS Reminders", desc: "Send order updates via SMS" },
              { key: "stock", label: "Stock Alerts", desc: "Get notified when stock runs low" },
            ].map((item) => (
              <label
                key={item.key}
                className="flex items-center justify-between p-4 cursor-pointer"
              >
                <div>
                  <p className="font-medium">{item.label}</p>
                  <p className="text-xs text-gray-500">{item.desc}</p>
                </div>
                <input
                  type="checkbox"
                  checked={notifications[item.key]}
                  onChange={() => toggleNotification(item.key)}
                  className="form-checkbox h-5 w-5 text-blue-600 rounded-full"
                />
              </label>
            ))}
          </div>
        </div>
      </div>

      {/* Mobile Sales App Sync Stats */}
      {/* Changes to grid-cols-2 on small screens and 4 on larger screens for better mobile layout */}
      <div
        className={`rounded-lg shadow-sm border mt-6 grid grid-cols-2 sm:grid-cols-4 text-center ${
          isDark ? "bg-gray-800 border-gray-700" : "bg-white border-gray-200"
        }`}
      >
        <div className="p-4">
          <p className="text-xl sm:text-2xl font-bold text-green-600">12</p>
          <p className="text-xs text-gray-500">Active Sales Reps</p>
        </div>
        <div className="p-4 border-l sm:border-l border-r sm:border-r">
          <p className="text-xl sm:text-2xl font-bold text-blue-600">45</p>
          <p className="text-xs text-gray-500">Orders Today</p>
        </div>
        <div className="p-4 sm:border-r">
          <p className="text-xl sm:text-2xl font-bold text-green-500">₹2.4L</p>
          <p className="text-xs text-gray-500">Sales Today</p>
        </div>
        <div className="p-4 flex flex-col items-center justify-center">
          <p className="text-xl sm:text-2xl font-bold text-yellow-500">2 min</p>
          <p className="text-xs text-gray-500">Last Sync</p>
          <span className="flex items-center mt-1 text-green-500 text-xs">
            <Wifi size={12} className="mr-1" /> Online
          </span>
        </div>
      </div>
    </div>
  );
}
