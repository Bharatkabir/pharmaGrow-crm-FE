import { useState } from "react";
import {
  Search,
  FileText,
  CheckCircle,
  Clock,
  DollarSign,
  Download,
  Eye,
  Send,
} from "lucide-react";

/**
 * Invoicing component with a responsive layout.
 * It displays a dashboard of invoicing metrics and a table of invoices.
 * The layout adapts for mobile, tablet, and desktop views.
 * @param {{ theme: string }} props
 */
export default function Invoicing({ theme }) {
  // Mock data for the invoice list
  const [invoices] = useState([
    {
      id: "INV-2024-001",
      customer: "City Hospital",
      orderId: "ORD-2024-001",
      issueDate: "2024-01-20",
      dueDate: "2024-02-19",
      amount: 5200,
      total: 5200,
      status: "Paid",
    },
    {
      id: "INV-2024-002",
      customer: "MedCare Pharmacy",
      orderId: "ORD-2024-002",
      issueDate: "2024-01-19",
      dueDate: "2024-02-18",
      amount: 3800,
      total: 4180,
      status: "Pending",
    },
    {
      id: "INV-2024-003",
      customer: "Regional Medical Center",
      orderId: "ORD-2024-003",
      issueDate: "2024-01-18",
      dueDate: "2024-02-17",
      amount: 7500,
      total: 8250,
      status: "Overdue",
    },
    {
      id: "INV-2024-004",
      customer: "HealthPlus Clinic",
      orderId: "ORD-2024-004",
      issueDate: "2024-01-17",
      dueDate: "2024-02-16",
      amount: 2100,
      total: 2100,
      status: "Paid",
    },
  ]);

  const isDark = theme === "dark";

  return (
    <div className={`p-4 md:p-6 ${isDark ? "bg-gray-900 text-white" : "bg-gray-50 text-gray-900"}`}>
      {/* Page Header */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center mb-6">
        <div>
          <h1 className="text-2xl md:text-3xl font-bold">Invoicing</h1>
          <p className={`mt-1 text-sm ${isDark ? "text-gray-400" : "text-gray-500"}`}>
            Manage invoices and track payments
          </p>
        </div>
        <div className="flex flex-col sm:flex-row space-y-2 sm:space-y-0 sm:space-x-2 mt-4 sm:mt-0 w-full sm:w-auto">
          <button
            className={`flex items-center justify-center px-4 py-2 rounded-lg shadow-sm border transition-colors w-full sm:w-auto
              ${isDark
                ? "bg-gray-800 text-gray-200 border-gray-700 hover:bg-gray-700"
                : "bg-gray-50 text-gray-700 border-gray-300 hover:bg-gray-100"
              }`}
          >
            <Download className="h-4 w-4 mr-2" />
            Export
          </button>
          <button className="flex items-center justify-center px-4 py-2 bg-blue-600 text-white rounded-lg shadow-sm hover:bg-blue-700 transition-colors w-full sm:w-auto">
            <svg
              xmlns="http://www.w3.org/2000/svg"
              className="h-4 w-4 mr-2"
              viewBox="0 0 20 20"
              fill="currentColor"
            >
              <path
                fillRule="evenodd"
                d="M10 5a1 1 0 011 1v3h3a1 1 0 110 2h-3v3a1 1 0 11-2 0v-3H6a1 1 0 110-2h3V6a1 1 0 011-1z"
                clipRule="evenodd"
              />
            </svg>
            Create Invoice
          </button>
        </div>
      </div>

      {/* Dashboard Metrics */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
        <div className={`${isDark ? "bg-gray-800" : "bg-white"} rounded-lg shadow-sm p-5 flex items-center justify-between`}>
          <div>
            <p className={`text-sm font-medium ${isDark ? "text-gray-400" : "text-gray-500"}`}>Total Invoices</p>
            <h2 className="text-2xl font-bold mt-1">4</h2>
          </div>
          <FileText className="h-10 w-10 text-blue-600" />
        </div>
        <div className={`${isDark ? "bg-gray-800" : "bg-white"} rounded-lg shadow-sm p-5 flex items-center justify-between`}>
          <div>
            <p className={`text-sm font-medium ${isDark ? "text-gray-400" : "text-gray-500"}`}>Paid Invoices</p>
            <h2 className="text-2xl font-bold mt-1">2</h2>
          </div>
          <CheckCircle className="h-10 w-10 text-green-600" />
        </div>
        <div className={`${isDark ? "bg-gray-800" : "bg-white"} rounded-lg shadow-sm p-5 flex items-center justify-between`}>
          <div>
            <p className={`text-sm font-medium ${isDark ? "text-gray-400" : "text-gray-500"}`}>Pending Amount</p>
            <h2 className="text-2xl font-bold mt-1">
              ${invoices.find(inv => inv.status === "Pending")?.total.toLocaleString() || "0"}
            </h2>
          </div>
          <Clock className="h-10 w-10 text-yellow-500" />
        </div>
        <div className={`${isDark ? "bg-gray-800" : "bg-white"} rounded-lg shadow-sm p-5 flex items-center justify-between`}>
          <div>
            <p className={`text-sm font-medium ${isDark ? "text-gray-400" : "text-gray-500"}`}>Overdue Amount</p>
            <h2 className="text-2xl font-bold mt-1">
              ${invoices.find(inv => inv.status === "Overdue")?.total.toLocaleString() || "0"}
            </h2>
          </div>
          <DollarSign className="h-10 w-10 text-red-600" />
        </div>
      </div>

      {/* Invoice Table */}
      <div className={`${isDark ? "bg-gray-800" : "bg-white"} rounded-lg shadow-sm p-4 md:p-6`}>
        <h2 className="text-base md:text-lg font-semibold mb-4">
          Invoice List ({invoices.length} invoices)
        </h2>
        <div className="overflow-x-auto">
          <table className="min-w-full divide-y divide-gray-200 dark:divide-gray-700">
            <thead className={isDark ? "bg-gray-700" : "bg-gray-50"}>
              <tr>
                {["Invoice ID", "Customer", "Order ID", "Issue Date", "Due Date", "Amount", "Total", "Status", "Actions"].map((header) => (
                  <th key={header} className={`px-3 md:px-6 py-3 text-left text-xs font-medium uppercase tracking-wider ${isDark ? "text-gray-300" : "text-gray-500"}`}>
                    {header}
                  </th>
                ))}
              </tr>
            </thead>
            <tbody className={`${isDark ? "bg-gray-800" : "bg-white"} divide-y divide-gray-200 dark:divide-gray-700`}>
              {invoices.map((invoice) => (
                <tr key={invoice.id} className={isDark ? "hover:bg-gray-700" : "hover:bg-gray-50"}>
                  <td className="px-3 md:px-6 py-4 whitespace-nowrap text-sm font-medium">{invoice.id}</td>
                  <td className="px-3 md:px-6 py-4 whitespace-nowrap text-sm">{invoice.customer}</td>
                  <td className="px-3 md:px-6 py-4 whitespace-nowrap text-sm">{invoice.orderId}</td>
                  <td className="px-3 md:px-6 py-4 whitespace-nowrap text-sm">{invoice.issueDate}</td>
                  <td className="px-3 md:px-6 py-4 whitespace-nowrap text-sm">{invoice.dueDate}</td>
                  <td className="px-3 md:px-6 py-4 whitespace-nowrap text-sm">${invoice.amount.toLocaleString()}</td>
                  <td className="px-3 md:px-6 py-4 whitespace-nowrap text-sm">${invoice.total.toLocaleString()}</td>
                  <td className="px-3 md:px-6 py-4 whitespace-nowrap">
                    <span
                      className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${
                        invoice.status === "Paid"
                          ? "bg-green-100 text-green-800 dark:bg-green-800 dark:text-green-100"
                          : invoice.status === "Pending"
                          ? "bg-yellow-100 text-yellow-800 dark:bg-yellow-800 dark:text-yellow-100"
                          : "bg-red-100 text-red-800 dark:bg-red-800 dark:text-red-100"
                      }`}
                    >
                      {invoice.status}
                    </span>
                  </td>
                  <td className="px-3 md:px-6 py-4 flex gap-2">
                    <button className={`p-2 border rounded-lg transition-colors ${isDark ? "border-gray-600 hover:bg-gray-700" : "border-gray-300 hover:bg-gray-100"}`}>
                      <Eye className="w-5 h-5" />
                    </button>
                    <button className={`p-2 border rounded-lg transition-colors ${isDark ? "border-gray-600 hover:bg-gray-700" : "border-gray-300 hover:bg-gray-100"}`}>
                      <Download className="w-5 h-5" />
                    </button>
                    <button className={`p-2 border rounded-lg transition-colors ${isDark ? "border-gray-600 hover:bg-gray-700" : "border-gray-300 hover:bg-gray-100"}`}>
                      <Send className="w-5 h-5" />
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
