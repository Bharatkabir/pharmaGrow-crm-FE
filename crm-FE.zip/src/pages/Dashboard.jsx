import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
} from "recharts";

export default function Dashboard({ theme }) {
  const salesData = [
    { month: "Jan", sales: 45000 },
    { month: "Feb", sales: 52000 },
    { month: "Mar", sales: 48000 },
    { month: "Apr", sales: 61000 },
    { month: "May", sales: 58000 },
    { month: "Jun", sales: 67000 },
  ];

  const productData = [
    { name: "Amoxicillin 500mg", units: 1250, change: 12.5 },
    { name: "Paracetamol 650mg", units: 980, change: -2.1 },
    { name: "Omeprazole 20mg", units: 875, change: 8.7 },
    { name: "Metformin 500mg", units: 720, change: 15.2 },
    { name: "Atorvastatin 10mg", units: 650, change: 13.4 },
  ];

  const stats = [
    { title: "Total Sales", value: "$67,200", change: "+12.5%" },
    { title: "Outstanding Payments", value: "$23,400", change: "-8.2%" },
    { title: "Total Orders", value: "1,250", change: "+18.7%" },
    { title: "Active Customers", value: "847", change: "+5.3%" },
  ];

  const recentActivities = [
    {
      text: "New order #ORD-2024-001 from City Hospital",
      time: "2 minutes ago",
      type: "success",
    },
    {
      text: "Payment received from MedCare Pharmacy - $5,200",
      time: "15 minutes ago",
      type: "success",
    },
    {
      text: "New customer registration: HealthPlus Clinic",
      time: "1 hour ago",
      type: "success",
    },
    {
      text: "Low stock alert: Amoxicillin 500mg (50 units remaining)",
      time: "2 hours ago",
      type: "warning",
    },
    {
      text: "Order #ORD-2024-082 shipped to Regional Medical Center",
      time: "3 hours ago",
      type: "success",
    },
  ];

  const mobileStats = [
    { label: "Active Field Reps", value: 12, color: "text-blue-600 dark:text-blue-400" },
    { label: "Today's Field Sales", value: "$8,450", color: "text-green-600 dark:text-green-400" },
    { label: "Customer Visits", value: 24, color: "text-pink-600 dark:text-pink-400" },
  ];

  const maxUnits = Math.max(...productData.map((p) => p.units));

  return (
    <div className="p-6 flex-1 bg-gray-50 dark:bg-gray-900 min-h-screen transition-colors">
      <h2 className="text-xl font-semibold text-gray-800 dark:text-gray-100">Dashboard</h2>
      <p className="text-sm text-gray-500 dark:text-gray-400 mb-6">
        Welcome back! Here's what's happening with your pharma business today.
      </p>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
        {stats.map((stat) => (
          <div
            key={stat.title}
            className="bg-white dark:bg-gray-800 p-4 rounded-lg shadow-sm transition-colors"
          >
            <h3 className="text-sm text-gray-500 dark:text-gray-400">{stat.title}</h3>
            <p className="text-xl font-bold text-gray-900 dark:text-gray-100">{stat.value}</p>
            <p
              className={`text-sm ${
                stat.change.startsWith("+")
                  ? "text-green-600 dark:text-green-400"
                  : "text-red-600 dark:text-red-400"
              }`}
            >
              {stat.change} from last month
            </p>
          </div>
        ))}
      </div>

      {/* Charts Section */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Sales Growth */}
        <div className="bg-white dark:bg-gray-800 p-4 rounded-lg shadow-sm transition-colors">
          <h3 className="font-semibold text-gray-800 dark:text-gray-100 mb-4">Monthly Sales Growth</h3>
          <ResponsiveContainer width="100%" height={250}>
            <LineChart data={salesData}>
              <CartesianGrid strokeDasharray="3 3" stroke={theme === "dark" ? "#4B5563" : "#E5E7EB"} />
              <XAxis dataKey="month" stroke={theme === "dark" ? "#D1D5DB" : "#374151"} />
              <YAxis stroke={theme === "dark" ? "#D1D5DB" : "#374151"} />
              <Tooltip
                contentStyle={{
                  backgroundColor: theme === "dark" ? "#1F2937" : "#fff",
                  color: theme === "dark" ? "#F9FAFB" : "#111827",
                }}
              />
              <Line
                type="monotone"
                dataKey="sales"
                stroke="#2563eb"
                strokeWidth={2}
              />
            </LineChart>
          </ResponsiveContainer>
        </div>

        {/* Top Products */}
        <div className="bg-white dark:bg-gray-800 p-4 rounded-lg shadow-sm transition-colors">
          <h3 className="font-semibold text-gray-800 dark:text-gray-100 mb-4">Top 5 Products</h3>
          <div className="space-y-4">
            {productData.map((product, idx) => (
              <div key={idx}>
                <div className="flex justify-between items-center">
                  <div>
                    <p className="font-medium text-gray-800 dark:text-gray-100">{product.name}</p>
                    <p className="text-sm text-gray-500 dark:text-gray-400">
                      {product.units} units
                    </p>
                  </div>
                  <span
                    className={`px-2 py-0.5 text-xs font-semibold rounded-full ${
                      product.change >= 0
                        ? "bg-blue-100 text-blue-700 dark:bg-blue-900 dark:text-blue-300"
                        : "bg-red-100 text-red-700 dark:bg-red-900 dark:text-red-300"
                    }`}
                  >
                    {product.change > 0
                      ? `+${product.change}%`
                      : `${product.change}%`}
                  </span>
                </div>
                <div className="w-full bg-gray-200 dark:bg-gray-700 h-1.5 rounded-full mt-1">
                  <div
                    className="bg-blue-600 h-1.5 rounded-full"
                    style={{
                      width: `${(product.units / maxUnits) * 100}%`,
                    }}
                  />
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Recent Activities */}
      <div className="bg-white dark:bg-gray-800 p-4 rounded-lg shadow-sm mt-6 transition-colors">
        <h3 className="font-semibold text-gray-800 dark:text-gray-100 mb-4">Recent Activities</h3>
        <ul className="space-y-3">
          {recentActivities.map((activity, idx) => (
            <li key={idx} className="flex items-start gap-2">
              <span
                className={`w-3 h-3 rounded-full mt-1 ${
                  activity.type === "success"
                    ? "bg-green-500"
                    : "bg-yellow-500"
                }`}
              ></span>
              <div>
                <p className="text-sm text-gray-800 dark:text-gray-100">{activity.text}</p>
                <p className="text-xs text-gray-500 dark:text-gray-400">{activity.time}</p>
              </div>
            </li>
          ))}
        </ul>
      </div>

      {/* Mobile Sales Stats */}
      <div className="bg-white dark:bg-gray-800 p-4 rounded-lg shadow-sm mt-6 transition-colors">
        <h3 className="font-semibold text-gray-800 dark:text-gray-100 mb-4">
          Mobile Sales App - Real-time Stats
        </h3>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-center">
          {mobileStats.map((stat, idx) => (
            <div key={idx}>
              <p className={`text-2xl font-bold ${stat.color}`}>{stat.value}</p>
              <p className="text-sm text-gray-500 dark:text-gray-400">{stat.label}</p>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}