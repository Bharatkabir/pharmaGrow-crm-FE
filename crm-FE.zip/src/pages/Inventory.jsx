import { useState } from "react";
import { Search, Package, AlertTriangle, TrendingUp, TrendingDown, Pencil } from "lucide-react";

/**
 * Inventory component with a responsive layout.
 * It displays a dashboard of inventory metrics and a table of products.
 * The layout adapts for mobile, tablet, and desktop views.
 * @param {{ theme: string }} props
 */
export default function Inventory({ theme }) {
  // Mock data for the product list
  const [products] = useState([
    {
      id: "AMX2024001",
      name: "Amoxicillin 500mg",
      sku: "AMX-500-100",
      category: "Antibiotics",
      stockLevel: 50,
      maxStock: 1000,
      unitPrice: 15.5,
      supplier: "PharmaCorp Ltd",
      expiry: "2025-06-15",
      status: "Low Stock",
    },
    {
      id: "PAR2024002",
      name: "Paracetamol 650mg",
      sku: "PAR-650-200",
      category: "Analgesics",
      stockLevel: 850,
      maxStock: 2000,
      unitPrice: 8.25,
      supplier: "MediSupply Co",
      expiry: "2025-12-20",
      status: "In Stock",
    },
    {
      id: "OME2024003",
      name: "Omeprazole 20mg",
      sku: "OME-20-150",
      category: "Gastroenterology",
      stockLevel: 320,
      maxStock: 1500,
      unitPrice: 12,
      supplier: "HealthSource Inc",
      expiry: "2025-09-10",
      status: "In Stock",
    },
    {
      id: "INS2024004",
      name: "Insulin Glargine 100IU",
      sku: "INS-100-50",
      category: "Diabetes",
      stockLevel: 0,
      maxStock: 500,
      unitPrice: 45.75,
      supplier: "DiabetesCare Ltd",
      expiry: "2024-12-31",
      status: "Out of Stock",
    },
    {
      id: "MET2024005",
      name: "Metformin 500mg",
      sku: "MET-500-180",
      category: "Diabetes",
      stockLevel: 1200,
      maxStock: 2500,
      unitPrice: 6.5,
      supplier: "PharmaCorp Ltd",
      expiry: "2026-03-25",
      status: "In Stock",
    },
  ]);

  const isDark = theme === "dark";

  return (
    <div className={`p-4 md:p-6 ${isDark ? "bg-gray-900 text-gray-100" : "bg-gray-50 text-gray-900"}`}>
      {/* Page Header */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center mb-6">
        <div>
          <h1 className="text-2xl md:text-3xl font-bold">Inventory Management</h1>
          <p className="mt-1 text-sm text-gray-500 dark:text-gray-400">
            Track and manage your pharmaceutical inventory
          </p>
        </div>
        <button className="mt-4 sm:mt-0 flex items-center px-4 py-2 bg-blue-600 text-white rounded-lg shadow-sm hover:bg-blue-700 transition-colors w-full sm:w-auto justify-center">
          <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 mr-2" viewBox="0 0 20 20" fill="currentColor">
            <path fillRule="evenodd" d="M10 5a1 1 0 011 1v3h3a1 1 0 110 2h-3v3a1 1 0 11-2 0v-3H6a1 1 0 110-2h3V6a1 1 0 011-1z" clipRule="evenodd" />
          </svg>
          Add Product
        </button>
      </div>

      {/* Dashboard Metrics */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
        {[
          { label: "Total Products", value: "5", icon: Package, color: "text-blue-600" },
          { label: "Low Stock Alerts", value: "1", icon: AlertTriangle, color: "text-yellow-500" },
          { label: "Out of Stock", value: "1", icon: TrendingDown, color: "text-red-600" },
          { label: "Inventory Value", value: "$19,427.5", icon: TrendingUp, color: "text-green-600" },
        ].map(({ label, value, icon: Icon, color }) => (
          <div key={label} className={`rounded-lg shadow-sm p-5 flex items-center justify-between ${isDark ? "bg-gray-800" : "bg-white"}`}>
            <div>
              <p className="text-sm font-medium text-gray-500 dark:text-gray-400">{label}</p>
              <h2 className="text-2xl font-bold mt-1">{value}</h2>
            </div>
            <Icon className={`h-10 w-10 ${color}`} />
          </div>
        ))}
      </div>

      {/* Product List Table */}
      <div className={`${isDark ? "bg-gray-800" : "bg-white"} rounded-lg shadow-sm p-4 md:p-6`}>
        <h2 className="text-base md:text-lg font-semibold mb-4">Product Inventory ({products.length} products)</h2>
        <div className="overflow-x-auto">
          <table className="min-w-full divide-y divide-gray-200 dark:divide-gray-700">
            <thead className={`${isDark ? "bg-gray-700" : "bg-gray-50"}`}>
              <tr>
                {["Product", "SKU", "Category", "Stock Level", "Unit Price", "Supplier", "Expiry", "Status", "Actions"].map((header) => (
                  <th
                    key={header}
                    className={`px-3 md:px-6 py-3 text-left text-xs font-medium uppercase tracking-wider ${isDark ? "text-gray-300" : "text-gray-500"}`}
                  >
                    {header}
                  </th>
                ))}
              </tr>
            </thead>
            <tbody className={`${isDark ? "bg-gray-800" : "bg-white"} divide-y divide-gray-200 dark:divide-gray-700`}>
              {products.map((product) => (
                <tr key={product.id} className={isDark ? "hover:bg-gray-700" : "hover:bg-gray-50"}>
                  <td className="px-3 md:px-6 py-4 whitespace-nowrap">
                    <div className="text-sm font-medium">{product.name}</div>
                    <div className={`text-xs ${isDark ? "text-gray-400" : "text-gray-500"}`}>{product.id}</div>
                  </td>
                  <td className="px-3 md:px-6 py-4 whitespace-nowrap text-sm">{product.sku}</td>
                  <td className="px-3 md:px-6 py-4 whitespace-nowrap text-sm">{product.category}</td>
                  <td className="px-3 md:px-6 py-4 whitespace-nowrap text-sm">
                    <div className="w-24 bg-gray-200 rounded-full h-2.5 dark:bg-gray-700">
                      <div
                        className="bg-blue-600 h-2.5 rounded-full"
                        style={{ width: `${(product.stockLevel / product.maxStock) * 100}%` }}
                      />
                    </div>
                    <p className={`mt-1 text-xs ${isDark ? "text-gray-400" : "text-gray-500"}`}>{product.stockLevel} / {product.maxStock}</p>
                  </td>
                  <td className="px-3 md:px-6 py-4 whitespace-nowrap text-sm">${product.unitPrice.toLocaleString()}</td>
                  <td className="px-3 md:px-6 py-4 whitespace-nowrap text-sm">{product.supplier}</td>
                  <td className="px-3 md:px-6 py-4 whitespace-nowrap text-sm">{product.expiry}</td>
                  <td className="px-3 md:px-6 py-4 whitespace-nowrap">
                    <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${
                      product.status === "Low Stock" ? "bg-yellow-100 text-yellow-800 dark:bg-yellow-800 dark:text-yellow-100" :
                      product.status === "Out of Stock" ? "bg-red-100 text-red-800 dark:bg-red-800 dark:text-red-100" :
                      "bg-green-100 text-green-800 dark:bg-green-800 dark:text-green-100"
                    }`}>
                      {product.status}
                    </span>
                  </td>
                  <td className="px-3 md:px-6 py-4 whitespace-nowrap text-sm font-medium">
                    <button className={`flex items-center gap-1 p-2 border rounded-lg transition-colors ${isDark ? "text-gray-300 border-gray-600 hover:bg-gray-700" : "text-gray-600 border-gray-300 hover:bg-gray-100"}`}>
                      <Pencil className="w-5 h-5" />
                      Edit
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
