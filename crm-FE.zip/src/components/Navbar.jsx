import { useState, useRef, useEffect } from "react";
import { NavLink, useNavigate } from "react-router-dom";
import { useSelector, useDispatch } from "react-redux";
import {
  Search,
  Bell,
  Settings,
  Sun,
  Moon,
  Menu,
  ChevronDown,
  LogOut,
  User,
  X
} from "lucide-react";
import { logout, reset } from "../features/auth/authSlice";

export default function Navbar({ onToggleTheme, theme, onToggleSidebar }) {
  const { user } = useSelector((state) => state.auth); // Dynamic user from Redux
  const dispatch = useDispatch();
  const navigate = useNavigate();

  const [currency, setCurrency] = useState("INR");
  const [dropdownOpen, setDropdownOpen] = useState(false);
  const [currencyDropdownOpen, setCurrencyDropdownOpen] = useState(false);
  const [showMobileSearch, setShowMobileSearch] = useState(false);

  const dropdownRef = useRef(null);
  const currencyRef = useRef(null);
  const mobileSearchRef = useRef(null);

  const isDark = theme === "dark";

  // Compute initials from user name
  const initials = user?.name
    ? user.name
        .split(" ")
        .map((n) => n[0])
        .join("")
        .toUpperCase()
    : "";

  useEffect(() => {
    function handleClickOutside(e) {
      if (dropdownRef.current && !dropdownRef.current.contains(e.target)) {
        setDropdownOpen(false);
      }
      if (currencyRef.current && !currencyRef.current.contains(e.target)) {
        setCurrencyDropdownOpen(false);
      }
      if (mobileSearchRef.current && !mobileSearchRef.current.contains(e.target)) {
        setShowMobileSearch(false);
      }
    }
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  const currencies = [
    { code: "INR", symbol: "₹" },
    { code: "USD", symbol: "$" },
    { code: "EUR", symbol: "€" },
  ];

  const handleCurrencyChange = (newCurrency) => {
    setCurrency(newCurrency);
    setCurrencyDropdownOpen(false);
  };

  const handleLogout = async () => {
    await dispatch(logout());
    dispatch(reset());
    navigate("/login");
  };

  return (
    <>
      <header
        className={`h-20 px-4 flex items-center justify-between fixed top-0 left-0 right-0 z-50 transition-colors duration-300 ${
          isDark ? "bg-gray-900/80 border-b-2 border-gray-700" : "bg-white/80 border-b-2 border-gray-200"
        } backdrop-blur-lg`}
      >
        {/* Left Section: Mobile Menu + Logo */}
        <div className="flex items-center space-x-3 md:space-x-6">
          <button
            className="lg:hidden p-2 rounded-lg text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-700 transition-colors"
            onClick={onToggleSidebar}
          >
            <Menu className="h-6 w-6" />
          </button>

          <NavLink to="/dashboard" className="hidden lg:flex items-center space-x-3 group">
            <div className="w-12 h-12 flex items-center justify-center bg-blue-600 text-white font-bold rounded-xl shadow-lg transition-transform group-hover:scale-105">
              PG
            </div>
            <div>
              <h1 className="text-xl font-semibold text-gray-800 dark:text-gray-100">PharmaGrow CRM</h1>
              <p className="text-xs text-gray-500 dark:text-gray-400">Pharmaceutical Management</p>
            </div>
          </NavLink>
        </div>

        {/* Middle Section: Search (Desktop Only) */}
        <div className="hidden lg:flex items-center space-x-4 flex-1 max-w-xl mx-auto">
          <div className="relative flex-1">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-400 h-5 w-5" />
            <input
              type="text"
              placeholder="Search..."
              className={`w-full py-2.5 pl-12 pr-4 text-sm rounded-full transition-colors ${
                isDark ? "bg-gray-800 text-white border-gray-700 focus:border-blue-500" : "bg-gray-100 text-gray-800 border-gray-300 focus:border-blue-600"
              } focus:ring-2 focus:ring-blue-500 focus:outline-none`}
            />
          </div>
        </div>

        {/* Right Section: Mobile & Desktop */}
        <div className="flex items-center space-x-4 md:space-x-6">
          {/* Mobile Search */}
          <button
            onClick={() => setShowMobileSearch(true)}
            className="lg:hidden p-2 rounded-full text-gray-600 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-700 transition-colors"
          >
            <Search className="h-6 w-6" />
          </button>

          {/* Currency Selector */}
          <div className="relative flex" ref={currencyRef}>
            <button
              onClick={() => setCurrencyDropdownOpen(!currencyDropdownOpen)}
              className={`flex items-center py-2 px-4 rounded-lg border text-sm transition-colors cursor-pointer ${
                isDark ? "border-gray-700 text-white" : "border-gray-300 text-gray-800"
              } focus:outline-none focus:ring-2 focus:ring-blue-500`}
            >
              <span>{currencies.find(c => c.code === currency)?.symbol} {currency}</span>
              <ChevronDown className={`ml-2 h-4 w-4 text-gray-500 transition-transform ${currencyDropdownOpen ? "rotate-180" : ""}`} />
            </button>

            {currencyDropdownOpen && (
              <div
                className={`absolute right-0 top-12 w-32 rounded-xl shadow-xl py-2 z-50 transition-opacity animate-fade-in origin-top-right transform scale-100 ${
                  isDark ? "bg-gray-800 border border-gray-700" : "bg-white border border-gray-200"
                }`}
              >
                {currencies.map((c, index) => (
                  <button
                    key={index}
                    onClick={() => handleCurrencyChange(c.code)}
                    className="flex items-center w-full px-4 py-2 text-sm text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-700 transition-colors"
                  >
                    <span>{c.symbol} {c.code}</span>
                  </button>
                ))}
              </div>
            )}
          </div>

          {/* Theme toggle */}
          <button
            onClick={onToggleTheme}
            className="p-2 rounded-full text-gray-600 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-700 transition-colors"
          >
            {isDark ? <Sun className="text-yellow-400 h-6 w-6" /> : <Moon className="h-6 w-6" />}
          </button>

          {/* Notifications - only large screens */}
          <div className="hidden lg:flex relative cursor-pointer p-2 rounded-full text-gray-600 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-700 transition-colors">
            <Bell className="h-6 w-6" />
            <span className="absolute top-0 right-0 bg-red-500 text-white text-xs font-bold px-2 py-0.5 rounded-full ring-2 ring-white dark:ring-gray-900">
              3
            </span>
          </div>

          {/* User Avatar + Dropdown */}
          <div className="relative" ref={dropdownRef}>
            <button
              className="flex items-center space-x-3 cursor-pointer"
              onClick={() => setDropdownOpen((prev) => !prev)}
            >
              <div className="w-10 h-10 flex items-center justify-center bg-gradient-to-br from-blue-600 to-purple-600 text-white text-sm font-bold rounded-full shadow-md">
                {initials}
              </div>
              <div className="hidden lg:block text-left">
                <p className="font-semibold text-gray-800 dark:text-gray-100">{user?.name}</p>
                <p className="text-xs text-gray-500 dark:text-gray-400">{user?.email}</p>
              </div>
              <ChevronDown className={`h-4 w-4 text-gray-500 transition-transform hidden lg:block ${dropdownOpen ? "rotate-180" : ""}`} />
            </button>

            {dropdownOpen && (
              <div
                className={`absolute right-0 top-14 w-60 rounded-xl shadow-xl py-2 z-50 transition-opacity animate-fade-in ${
                  isDark ? "bg-gray-800 border border-gray-700" : "bg-white border border-gray-200"
                }`}
              >
                <div className="px-4 py-2 text-xs font-medium text-gray-500 dark:text-gray-400 uppercase">My Account</div>
                <NavLink to="/profile" className="flex items-center w-full px-4 py-2 text-sm text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-700 transition-colors">
                  <User className="mr-2 h-4 w-4" /> Profile Settings
                </NavLink>
                <NavLink to="/settings" className="flex items-center w-full px-4 py-2 text-sm text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-700 transition-colors">
                  <Settings className="mr-2 h-4 w-4" /> Settings
                </NavLink>
                <div className="border-t border-gray-200 dark:border-gray-700 my-1"></div>
                <button
                  onClick={handleLogout}
                  className="flex items-center w-full px-4 py-2 text-sm text-red-600 hover:bg-red-50 dark:hover:bg-red-700 dark:hover:text-white transition-colors"
                >
                  <LogOut className="mr-2 h-4 w-4" /> Sign Out
                </button>
              </div>
            )}
          </div>
        </div>
      </header>

      {/* Mobile Search Popup */}
      {showMobileSearch && (
        <div className="fixed inset-0 bg-black/50 z-[60] flex flex-col items-center p-4 animate-fade-in-down" ref={mobileSearchRef}>
          <div className="w-full max-w-xl relative mt-4 bottom-4">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-400 h-5 w-5" />
            <input
              type="text"
              placeholder="Search..."
              className={`w-full py-3 pl-12 pr-10 text-sm rounded-md transition-colors shadow-lg ${
                isDark ? "bg-gray-700 text-white border border-gray-600" : "bg-white text-gray-800 border border-gray-300"
              } focus:outline-none focus:ring-2 focus:ring-blue-500`}
              autoFocus
            />
            <button
              className="absolute right-2 top-1/2 -translate-y-1/2 p-2 rounded-full text-gray-500 hover:bg-gray-100 dark:hover:bg-gray-600 transition-all active:scale-90"
              onClick={() => setShowMobileSearch(false)}
            >
              <X className="h-5 w-5" />
            </button>
          </div>
        </div>
      )}
    </>
  );
}
