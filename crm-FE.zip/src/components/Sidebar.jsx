import { LayoutDashboard, Users, ShoppingCart, Package, FileText, BarChart2, Settings, X, HelpCircle } from "lucide-react";
import { NavLink } from "react-router-dom";

export default function Sidebar({ theme, sidebarOpen, onClose }) {
  const menuItems = [
    { name: "Customers", icon: <Users size={18} />, path: "/customers" },
    { name: "Orders", icon: <ShoppingCart size={18} />, path: "/orders" },
    { name: "Inventory", icon: <Package size={18} />, path: "/inventory" },
    { name: "Invoicing", icon: <FileText size={18} />, path: "/invoicing" },
    { name: "Reports", icon: <BarChart2 size={18} />, path: "/reports" },
    { name: "Subscription", icon: <FileText size={18} />, path: "/subscription" },
  ];

  const isDark = theme === "dark";

  return (
    <>
      {/* Overlay for mobile */}
      <div
        className={`fixed inset-0 bg-black bg-opacity-50 z-40 transition-opacity lg:hidden ${
          sidebarOpen ? "opacity-100" : "opacity-0 pointer-events-none"
        }`}
        onClick={onClose}
      ></div>

      <aside
        className={`fixed top-0 left-0 w-64 h-full flex flex-col justify-between border-r transition-transform duration-300 z-50
        ${isDark ? "bg-gray-900 border-gray-800" : "bg-white border-gray-200"}
        ${sidebarOpen ? "translate-x-0" : "-translate-x-full"} lg:translate-x-0 lg:top-20 lg:h-[calc(100vh-5rem)]`}
      >
        {/* Logo + Close Button for mobile */}
        <div className="lg:hidden flex items-center justify-between p-4 border-b">
          <div className="flex items-center">
            <div className="w-12 h-12 bg-blue-700 text-white flex items-center justify-center font-bold rounded-lg">PG</div>
            <span className="ml-3 text-lg font-semibold text-gray-800 dark:text-gray-100">PharmaGrow</span>
          </div>
          <button onClick={onClose} className="p-2 rounded-lg hover:bg-gray-200 dark:hover:bg-gray-800">
            <X size={20} className="text-gray-700 dark:text-gray-300" />
          </button>
        </div>

        {/* Menu */}
        <nav className="mt-8 space-y-1 flex-1">
          {/* Always show Dashboard at top */}
          <NavLink
            to="/dashboard"
            onClick={onClose}
            className={({ isActive }) =>
              `flex items-center gap-3 px-4 py-2 text-sm font-medium rounded-lg transition-colors
              ${
                isActive
                  ? isDark
                    ? "bg-gray-800 text-white"
                    : "bg-blue-50 text-blue-700"
                  : isDark
                  ? "text-gray-300 hover:bg-gray-800 hover:text-white"
                  : "text-gray-600 hover:bg-gray-50"
              }`
            }
          >
            <LayoutDashboard size={18} />
            <span>Dashboard</span>
          </NavLink>

          {menuItems.map((item) => (
            <NavLink
              key={item.name}
              to={item.path}
              onClick={onClose}
              className={({ isActive }) =>
                `flex items-center gap-3 px-4 py-2 text-sm font-medium rounded-lg transition-colors
                ${
                  isActive
                    ? isDark
                      ? "bg-gray-800 text-white"
                      : "bg-blue-50 text-blue-700"
                    : isDark
                    ? "text-gray-300 hover:bg-gray-800 hover:text-white"
                    : "text-gray-600 hover:bg-gray-50"
                }`
              }
            >
              {item.icon}
              <span>{item.name}</span>
            </NavLink>
          ))}
        </nav>

        {/* Bottom Section: Help + Settings */}
        <div className={`p-4 border-t ${isDark ? "border-gray-800" : "border-gray-200"} space-y-2`}>
          <NavLink
            to="/help"
            onClick={onClose}
            className={`flex items-center gap-3 text-sm font-medium transition-colors
              ${isDark ? "text-gray-300 hover:text-white" : "text-gray-600 hover:text-gray-900"}`}
          >
            <HelpCircle size={18} /> <span>Help</span>
          </NavLink>
          <NavLink
            to="/settings"
            onClick={onClose}
            className={`flex items-center gap-3 text-sm font-medium transition-colors
              ${isDark ? "text-gray-300 hover:text-white" : "text-gray-600 hover:text-gray-900"}`}
          >
            <Settings size={18} /> <span>Settings</span>
          </NavLink>
        </div>
      </aside>
    </>
  );
}
