import { BrowserRouter as Router, Routes, Route, Navigate } from "react-router-dom";
import { useSelector, useDispatch } from "react-redux";
import { useState, useEffect } from "react";

import Navbar from "./components/Navbar";
import Sidebar from "./components/Sidebar";
import Login from "./pages/Login";
import Signup from "./pages/Signup";
import Dashboard from "./pages/Dashboard";
import Customers from "./pages/Customers";
import Orders from "./pages/Orders";
import Inventory from "./pages/Inventory";
import Invoicing from "./pages/Invoicing";
import Reports from "./pages/Reports";
import Subscription from "./pages/Subscription";
import Settings from "./pages/Settings";
import Help from "./pages/Help";
import { ToastContainer } from "react-toastify";

import { getUser } from "./features/auth/authSlice";

function App() {
  const dispatch = useDispatch();
  const { user, isLoading } = useSelector((state) => state.auth);

  const [theme, setTheme] = useState("light");
  const [sidebarOpen, setSidebarOpen] = useState(false);

  useEffect(() => {
    dispatch(getUser());
  }, [dispatch]);

  const toggleTheme = () => {
    setTheme(theme === "light" ? "dark" : "light");
  };

  // Show nothing or loading while fetching user
  if (isLoading) return <div className="flex justify-center items-center h-screen">Loading...</div>;

  return (
    <Router>
<ToastContainer
  position="top-right"
  autoClose={3000}
  hideProgressBar={false}
  newestOnTop={false}
  closeOnClick
  rtl={false}
  pauseOnFocusLoss
  draggable
  pauseOnHover
/>
      {!user ? (
        <Routes>
          <Route path="/" element={<Login />} />
          <Route path="/signup" element={<Signup />} />
          <Route path="*" element={<Navigate to="/" />} />
        </Routes>
      ) : (
        <div className={theme}>
          <div className="dark:bg-gray-900">
            <Navbar
              onToggleTheme={toggleTheme}
              theme={theme}
              onToggleSidebar={() => setSidebarOpen(true)}
            />
            <Sidebar
              theme={theme}
              sidebarOpen={sidebarOpen}
              onClose={() => setSidebarOpen(false)}
            />
            <main className="lg:ml-64 mt-20 p-6 bg-gray-50 dark:bg-gray-900 overflow-y-auto h-[calc(100vh-5rem)]">
              <Routes>
                <Route path="/dashboard" element={<Dashboard theme={theme} />} />
                <Route path="/customers" element={<Customers theme={theme} />} />
                <Route path="/orders" element={<Orders theme={theme} />} />
                <Route path="/inventory" element={<Inventory theme={theme} />} />
                <Route path="/invoicing" element={<Invoicing theme={theme} />} />
                <Route path="/reports" element={<Reports theme={theme} />} />
                <Route path="/subscription" element={<Subscription theme={theme} />} />
                <Route path="/help" element={<Help theme={theme} />} />
                <Route path="/settings" element={<Settings theme={theme} />} />
                <Route path="*" element={<Navigate to="/dashboard" />} />
              </Routes>
            </main>
          </div>
        </div>
      )}
    </Router>
  );
}

export default App;
