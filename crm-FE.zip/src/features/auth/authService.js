import axios from "axios";

const API_URL = "http://127.0.0.1:8000/api/auth/";

// Register user
const register = async (userData) => {
  const response = await axios.post(API_URL + "register", userData);
  return response.data;
};

// Login user
const login = async (userData) => {
  const response = await axios.post(API_URL + "login", userData);
  if (response.data.token) {
    localStorage.setItem("userToken", response.data.token);
  }
  return response.data;
};

// Get user details
const getUser = async () => {
  const token = localStorage.getItem("userToken");
  const response = await axios.get(API_URL + "user", {
    headers: { Authorization: `Bearer ${token}` },
  });
  return response.data;
};

// Logout user
const logout = async () => {
  const token = localStorage.getItem("userToken");
  await axios.post(
    API_URL + "logout",
    {},
    { headers: { Authorization: `Bearer ${token}` } }
  );
  localStorage.removeItem("userToken");
};

const authService = {
  register,
  login,
  getUser,
  logout,
};

export default authService;
